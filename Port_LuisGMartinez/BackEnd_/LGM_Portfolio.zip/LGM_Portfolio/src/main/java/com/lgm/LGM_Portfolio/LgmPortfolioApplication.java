package com.lgm.LGM_Portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LgmPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(LgmPortfolioApplication.class, args);
	}

}
