package com.PortLuisGMartinez.LGM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LgmApplication {

	public static void main(String[] args) {
		SpringApplication.run(LgmApplication.class, args);
	}

}
