package com.PortLuisGMartinez.LGM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LgmApplicationTests {

	@Test
	void contextLoads() {
	}

}
